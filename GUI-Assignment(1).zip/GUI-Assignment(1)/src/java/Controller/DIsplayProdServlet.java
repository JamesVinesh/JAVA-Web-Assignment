/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Prod;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AdminDisplayProd")
public class DIsplayProdServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ProdDa prodDa = new ProdDa();
        ArrayList<Prod> product = prodDa.getProduct();
        
        request.setAttribute("product", product);
        RequestDispatcher rd = request.getRequestDispatcher("AdminDisplayProd.jsp");
        rd.forward(request, response);
    } 
    
}
