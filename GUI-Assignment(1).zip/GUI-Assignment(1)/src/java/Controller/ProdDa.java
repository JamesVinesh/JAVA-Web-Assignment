/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Prod;
import java.sql.*;
import java.util.ArrayList;

public class ProdDa {
    
    private String host = "jdbc:derby://localhost:1527/Appliance";
    private String user = "James";
    private String password = "1234";
    private String tableName = "PRODUCTS";
    private Connection conn;
    private PreparedStatement stmt;
    private String sqlQueryStr = "Select * from " + tableName;
    private String sqlInsertStr = "INSERT INTO " + tableName + " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private ResultSet rs;
    
    public ProdDa(){
        
        try{
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(host, user, password);          
        }
        catch(Exception ex){
            ex.printStackTrace();
        }   
    }
    
    public Prod getCurrentRecord(){
        Prod prod = null;
        
        try{
            prod = new Prod(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getString(4), rs.getDouble(5), rs.getString(6), rs.getInt(7), rs.getString(8));
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return prod;
    }
    
    public void addRecord(Prod prod){
        try{
            PreparedStatement stmt = conn.prepareStatement(sqlInsertStr);
            stmt.setInt(1, prod.getProdID());
            stmt.setInt(2, prod.getAdminID());
            stmt.setString(3, prod.getCategory());
            stmt.setString(4, prod.getProdName());
            stmt.setDouble(5, prod.getProdPrice());
            stmt.setString(6, prod.getProdDesc());
            stmt.setInt(7, prod.getStock());
            stmt.setString(8, prod.getProdImage());
            stmt.setString(9, prod.getImagePath());
            stmt.executeUpdate();
        }
        catch(SQLException ex){
            ex.getMessage();
        }
    }
    
    public ArrayList<Prod> getProduct(){
        
        ArrayList<Prod> product = new ArrayList<>();
        try{
            stmt = conn.prepareStatement(sqlQueryStr);
            rs = stmt.executeQuery();
            while(rs.next()){
                product.add(getCurrentRecord());
            }
            
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        
        return product;
    }
     
    
}
